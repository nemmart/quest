#!/usr/bin/env python3
"""gen_declarations.py — GENERATE game/declarations.h and game/declarations.json.

The world layout as the reconstructed source sees it: the three shared-
memory base pointers (SD_PTR, OBJ_PTR, CAS_PTR), the key globals, and the
record tables the P35 routines touch.  Sources: docs/GAME_REFERENCE.md
(addresses, names) + docs/Project34/Census.md §3 (strides, raw field
displacements K, the 1-based origin rule origin = minK + stride).

Field names are `f<K>` (K = the raw word displacement from the base, as
readable.py names them) unless a meaning is known.  The .h is the ONLY
game file whose C and C++ views differ (game/README.md); the .json is the
same table for compiler/translate.py, which needs the numbers, not types.

    python3 compiler/gen_declarations.py [--out game/]
"""
import argparse, hashlib, json, os, re, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))

# ---------------------------------------------------------------------------
# THE TABLE (hand-seeded; every row cites its source)
# ---------------------------------------------------------------------------

# static scalars: name -> (word address, width in bits, comment)
STATICS = {
    "SD_PTR":     (0x70000210, 32, "GAME_REFERENCE: player records, world state (pointer)"),
    "OBJ_PTR":    (0x70000212, 32, "GAME_REFERENCE: object/item placement data (pointer)"),
    "CAS_PTR":    (0x70000214, 32, "GAME_REFERENCE: castle data (pointer)"),
    "PLAYER_NUM": (0x70000216, 16, "GAME_REFERENCE: current player index"),
    "OUT_CHAN":   (0x70000260, 32, "GAME_REFERENCE: output channel (?WRITE_SCREEN arg 1)"),
    "IN_CHAN":    (0x70000262, 32, "GAME_REFERENCE: input channel"),
    "CITY_NUM":   (0x7000026C, 16, "GAME_REFERENCE"),
    "TERR_NUM":   (0x7000026E, 16, "GAME_REFERENCE"),
    "MOVES_LEFT": (0x70000270, 16, "GAME_REFERENCE"),
}

# direct fields through a base pointer: pointer -> {name: (K, width, comment)}
DIRECT = {
    "SD_PTR": {
        "seed":        (40, 32, "P34 Census §3: the ?RANDOM_NUMBER seed (SD_PTR->f40)"),
        "f42":         (42, 16, "P34 Census §3"),
        "player_count": (43, 16, "UPDATE_SCREENS loop bound (SD_PTR->f43.h)"),
    },
    "OBJ_PTR": {
        # P51 §2.1 / P53 a002: the word before LANDMASS element 1 — the same
        # idiom as REGION's region_count at 11502.  It is also LANDMASS[0].y2
        # by K, which is what "the word before element 1" means.
        "landmass_count": (1035307, 16,
                           "P51 FAKE_LAND_MASS: land-mass count (OBJ_PTR->landmass_count)"),
        "region_count": (11502, 32, "P34 Census §3 / PICK_X_Y_reading: region count (OBJ_PTR->f11502)"),
        # P40/QUEST.1 7015C5F0: LNLDA 1,[ac2+0xDE890], stored to the R21e limit
        # temp — the DO bound over CASTLE, whose own DERR 17 bound is 1000.
        "f911504": (911504, 16, "P40/QUEST.1: the DO limit over CASTLE (OBJ_PTR->f911504)"),
    },
}

# record tables: name -> dict(base pointer, stride, minK (field 0's raw K), bound, fields{name:(K,width)})
# origin = minK + stride (P34 origin rule); element i (1-based) at base + i*stride + K.
TABLES = {
    "REGION": dict(base="OBJ_PTR", stride=9, minK=11495, bound=100000,
                   comment="P34 Census §3 OBJ_PTR_rec9; bound 100000 = PICK_X_Y's DERR 17 check",
                   fields={"x": (11495, 16), "y": (11496, 16), "type": (11497, 16),
                           "f11498": (11498, 32), "f11500": (11500, 32),
                           "f11502": (11502, 16), "f11503": (11503, 16)}),
    "PLAYER": dict(base="SD_PTR", stride=686, minK=-686 + 0, bound=10,
                   comment="P34 Census §3 SD_PTR_rec686; bound 10 = the DERR 17 check on PLAYER_NUM; "
                           "K < 0 in this table are raw displacements (origin unknown: min K seen −642)",
                   fields={"fm589": (-589, 16), "fm588": (-588, 16),
                           "screen": (-611, 32, (9, 11), (22, 2)),   # UPDATE_SCREENS: 9 rows x 11 cells of 2 words, raw K -611
                           "f19": (19, 32), "fm625": (-625, 16), "fm608": (-608, 16),
                           "fm590": (-590, 16),   # DIED: bit 4 of this word is the first test (bit address 16*i*686-9436)
                           "fm591": (-591, 16),   # P37/OWNS + DIED: the second bit word (bits 14, 15 seen in OWNS)
                           # P37/OWNS 70175CDB: PLAYER(p).fm390(i), 10 x 16-bit, inner stride 1 word,
                           # 1-based (the DERR 17 bound on i is 10, as it is on p)
                           # P39/LIST_PLAYERS.3 7016F59F: XNLDA 0,[ac2+0x7D8B]
                           "fm629": (-629, 16),
                           # P39/FIRE.2 7016A497: XNLDA 2,[ac2+0x7E88] (-376);
                           # 7016A4A0 XNLDA 0,[ac2+0x7E86] (-378) and its store;
                           # 7016A4CB XNLDA 2,[ac2+0x7E85] (-379); 7016A4E1 (-89)
                           "fm376": (-376, 16), "fm378": (-378, 16),
                           "fm379": (-379, 16), "fm89": (-89, 16),
                           "fm390": (-390, 16, (10,), (1,))}),
    # P40/QUEST.1 7015C60B: NLDAI 23; WMUL; LWADD 1,[0x70000214] (CAS_PTR),
    # then XNLDA from wp(ac2,-23) and wp(ac2,-22); the DERR 17 bound is 1000.
    # fm23/fm22 are compared against PLAYER.fm589/.fm588, which UPDATE_SCREENS
    # shows are the player's map x and y — so these are a castle's x and y.
    # Kept as raw fmNN names: the correspondence is a reading, not a derivation.
    # P53 a002 (Q-3 granted): the LANDMASS table, VERBATIM from P51 REPORT §2.1.
    # FAKE_LAND_MASS declared this locally in its own .c because the geometry
    # had nowhere else to live; a second home for geometry is a divergence
    # waiting to happen, so it comes here and the .c loses its struct.
    #
    # CONFIDENCE, carried forward as a002 required: P51 §1 marks the field
    # NAMES (cell, x1, y1, x2, y2) as **claimed**, NOT derived — they rest on
    # their uses in FAKE_LAND_MASS alone.  The LOGIC is derived (blind ×2); the
    # names are not.  CREATE_MAP's writer (701652xx/701653xx) would settle them
    # (P51 §6.1) and was deliberately not read here: the compiler does not care
    # what the fields are called, and moving a single-witness claim into a
    # canonical file is exactly how such claims get laundered.
    "LANDMASS": dict(base="OBJ_PTR", stride=22, minK=1035286, bound=1000,
                     origin=1035308,
                     comment="P51 FAKE_LAND_MASS + CREATE_MAP 701744CA..EC: named "
                             "land-mass rectangles; bound 1000 = DERR 17 at 701697DD; "
                             "origin base+1035308 if `cell` is field 0; `name` is "
                             "CHAR(30) VARYING (length word at +2, data at byte "
                             "2*0xFCC19).  FIELD NAMES ARE CLAIMED, NOT DERIVED "
                             "(P51 §1/§6.1): they rest on their uses in FAKE_LAND_MASS "
                             "alone; CREATE_MAP's writer would settle them.",
                     fields={"cell": (1035286, 32), "name_len": (1035288, 16),
                             "x1": (1035304, 16), "y1": (1035305, 16),
                             "x2": (1035306, 16), "y2": (1035307, 16)}),
    "CASTLE": dict(base="CAS_PTR", stride=23, minK=-23, bound=1000,
                   comment="P40/QUEST.1 CAS_PTR_rec23; bound 1000 = QUEST.1's DERR 17 check",
                   fields={"fm23": (-23, 16), "fm22": (-22, 16)}),
}


# ---------------------------------------------------------------------------
# PARENT FRAMES — the static link's target layout (P39)
# ---------------------------------------------------------------------------
# A nested procedure reaches its enclosing procedure's variables through the
# link at wp(fp, -6).  To emit the displacement the translator needs the
# PARENT's frame layout, which is not known from the parent's own source (no
# parent is reconstructed yet) — so it is recorded here, slot by slot, as the
# nested procedures witness it.
#
# USER RULING (P39 gate, Sep 9 2026) — a slot enters this table ONLY with a
# recorded WIDTH and a NAMED WITNESS.  Sibling nested procedures must agree on
# their common parent's layout INDEPENDENTLY; a disagreement is a finding, not
# something to reconcile.  That mutual check is the difference between deriving
# the parent's frame and fitting it.  `check_frames()` below enforces the
# mechanical half (width + witness present); the independence is procedural.
#
# name -> dict(argc, args{k: (width, witness, comment)}, locals{name: (slot, width, witness, comment)})
# `args` carries the parent's OWN parameters, reached as UPARG(P, k): they are
# by-reference, so the width is the width of the DATUM, not of the slot.  They
# obey the same witness rule as the locals.
# Slot numbers are WORD displacements off the parent's frame pointer, exactly
# as they appear in the IR: `wp(link, slot)`.  Locals are named `w<slot>` when
# the meaning is not known — the same convention readable.py uses for fields.
PARENT_FRAMES = {
    # P40/QUEST.1 is `nested` and so receives the link (R42: ac1, saved by
    # WSAVS at wp(fp,-6)), but it makes ZERO uplevel references — no
    # `wp(ac3,-6)` load appears anywhere in its 70 statements.  The entry
    # exists so `UPLINK(QUEST)` type-checks; it records no slots because
    # QUEST.1 witnesses none.  An empty frame asserts nothing about QUEST.
    "QUEST": dict(argc=0, args={}, locals={}),
    "LIST_PLAYERS": dict(
        argc=0, args={},
        locals={
            "w13": (13, 16, "LIST_PLAYERS.3@7016F5A2",
                    "XNLDA 1,[ac2+0xD] — compared against PLAYER(i).fm629"),
        },
        # P45 taint marker (docs/Salvage.md §3).  Status re-derived by P45
        # from Disassembled/quest.dis (docs/Project45/verify_frames.py), NOT
        # relayed from the attic.  LIST_PLAYERS.3 is the only NESTED witness,
        # but the parent's own body reaches slot 13 twice at 16-bit width —
        # 7016ECA6 `XNSTA 0,[ac3+0xD]` and 7016ECD7 `XNADI 1,[ac3+0xD]`.
        # Those PCs sit inside LIST_PLAYERS.1's addrbook range, but they are
        # PARENT code: the .1 ON-unit is only 7016EC57..7016EC73 (WSAVS 0x09
        # … I.GOTO) and the parent resumes at 7016EC74 (METHOD §16, the
        # DROP.1 shape).  Two independent witness classes agree on
        # displacement and width, so the slot is DERIVED under P41's restated
        # guard, not single-witness as P41 recorded.
        _taint={
            "w13": dict(status="derived", witnesses=3,
                        independent=["LIST_PLAYERS.3", "LIST_PLAYERS"],
                        note="P41 recorded single-witness; parent body x2 at "
                             "7016ECA6/7016ECD7 (in LIST_PLAYERS.1's mis-sized "
                             "addrbook range) corroborates 16-bit slot 13",
                        verified="P45 against quest.dis, Sep 12 2026"),
        }),
    "FIRE": dict(
        argc=2,
        # P41 Item 1: FIRE.1 and FIRE.2 reach DISJOINT slots, so the P39
        # sibling check was vacuous on that pair and every entry below was
        # single-witness.  Discharged instead against the whole family —
        # FIRE.3@7016A4F8 (18 link loads, unused by P39) overlaps both
        # siblings, and FIRE's own body reads its own frame directly.  Zero
        # disagreements.  arg 2 and w8 are the two slots that check found
        # missing.  See docs/Project41/FIRE_MUTUAL_CHECK.md.
        args={1: (16, "FIRE.2@7016A479",
                  "XNLDA 1,@[ac2+0xFFF4] — a PLAYER subscript (DERR 17 bound 10); "
                  "also FIRE.3 ×12 and FIRE's own body ×10"),
              2: (16, "FIRE.3@7016A6C7",
                  "XNLDA 0,@[ac2+0xFFF2] — a subscript with DERR 17 bound 100, "
                  "NOT the bound-10 one of arg 1; also FIRE's own body ×2")},
        locals={
            "w8": (8, 16, "FIRE.3@7016A557",
                   "XNLDA 0,[ac2+0x8]; 16-bit — FIRE.3 ×8 plus one XPEF, and "
                   "FIRE's own body ×11 (XNLDA/XNSTA)"),
            "w10": (10, 32, "FIRE.1@7016A3C0",
                    "XWLDA 0,[ac2+0xA]; a REGION subscript (DERR 17 bound 100000); "
                    "also FIRE.3 ×2 and FIRE's own XWSTA 2,[ac3+0xA]"),
            "w12": (12, 32, "FIRE.2@7016A485",
                    "XWLDA 0,[ac2+0xC]; a PLAYER subscript (DERR 17 bound 10); "
                    "no sibling second witness — corroborated by FIRE's own body ×10"),
            "w14": (14, 32, "FIRE.1@7016A3DC",
                    "XWSTA 0,[ac3+0xE] — WRITTEN uplevel, and read back at 7016A401; "
                    "also FIRE.3 ×6.  FIRE itself NEVER touches this slot, so only "
                    "the siblings can witness it"),
        },
        # P45 taint markers (docs/Salvage.md §3).  Every count below was
        # RE-DERIVED by P45 from Disassembled/quest.dis with
        # docs/Project45/verify_frames.py — a linear scan tracking which
        # accumulator holds the static link (ac1 at entry; XWLDA n,[ac3+0x7FFA]
        # thereafter) in each child, and every [ac3+d] with ac3 = fp in the
        # parent's own body — and compared against P41's counts AFTER the
        # scan.  Zero disagreements with P41; zero disagreements between
        # witness classes on displacement or width.  A slot is DERIVED when at
        # least two independent classes of {FIRE.1, FIRE.2, FIRE.3, FIRE's own
        # body} reach it (P41's restated guard); none is single-witness.
        # `witnesses` is the total reference count across all classes.
        _taint={
            "args.1": dict(status="derived", witnesses=25,
                           independent=["FIRE.2", "FIRE.3", "FIRE"],
                           verified="P45 against quest.dis, Sep 12 2026"),
            "args.2": dict(status="derived", witnesses=3,
                           independent=["FIRE.3", "FIRE"],
                           note="FIRE.3 x1 (7016A6C7) + parent body x2 "
                                "(70169D6B, 7016A098)",
                           verified="P45 against quest.dis, Sep 12 2026"),
            "w8":  dict(status="derived", witnesses=20,
                        independent=["FIRE.3", "FIRE"],
                        verified="P45 against quest.dis, Sep 12 2026"),
            "w10": dict(status="derived", witnesses=6,
                        independent=["FIRE.1", "FIRE.3", "FIRE"],
                        verified="P45 against quest.dis, Sep 12 2026"),
            "w12": dict(status="derived", witnesses=12,
                        independent=["FIRE.2", "FIRE"],
                        note="no sibling second witness; parent body x10 "
                             "(XWLDA/XWSTA [ac3+0xC], all 32-bit)",
                        verified="P45 against quest.dis, Sep 12 2026"),
            "w14": dict(status="derived", witnesses=9,
                        independent=["FIRE.1", "FIRE.3"],
                        note="parent never touches +14; FIRE.1 x3 incl. the "
                             "XPEF at 7016A3F2 (link loaded via ac2-held fp), "
                             "FIRE.3 x6 (7016A79B has the link in ac3)",
                        verified="P45 against quest.dis, Sep 12 2026"),
        }),
}


def _instruction_text():
    """Map instruction-start PC -> the disassembly's text for it, or None if the
    listing is not available (the generator must still run in a bare tree).

    Only real instruction lines are taken.  The hex-dump lines of the data
    areas have the same 8-hex-then-space shape, so they are excluded by
    requiring a mnemonic: text that starts with a letter and is not the
    `NNNN NNNN ...  [ascii]` form.  That matters, because a witness PC that
    landed in the data dump would otherwise pass the boundary check."""
    path = os.path.join(ROOT, "..", "Disassembled", "quest.dis")
    if not os.path.exists(path):
        return None
    out = {}
    for line in open(path, errors="replace"):
        if len(line) <= 8 or line[8] != " " or line[7] == " ":
            continue
        try:
            pc = int(line[:8], 16)
        except ValueError:
            continue
        text = line[8:].strip().rstrip(";").strip()
        if text[:1].isalpha():
            out[pc] = text
    return out or None


def _quoted_insn(comment):
    """The instruction a witness comment quotes: its leading text, up to the
    first `;` or em-dash.  Every PARENT_FRAMES comment is written in that
    form (`XWSTA 0,[ac3+0xE] — WRITTEN uplevel...`)."""
    head = re.split(r";|\u2014", comment or "", 1)[0].strip()
    return head if head[:1].isalpha() else None


def check_frames():
    """The user ruling, enforced: width and a named witness, or it does not go
    in.  A missing witness is a HARD ERROR, not a warning — the whole point of
    the rule is that a slot cannot arrive by convenience.

    P41: the rule as first implemented checked only that a witness STRING
    existed, not that its PC named a real instruction.  Three of the five
    entries then in the table were wrong (FIRE w12 7016A483 and LIST_PLAYERS
    w13 7016F59F were mid-instruction addresses; FIRE w14 7016A3DA named the
    link LOAD rather than the reference its own comment quotes).  A witness
    that cannot be looked up is not a witness, so the PC is now checked
    against the disassembly.  See docs/Project41/FIRE_MUTUAL_CHECK.md.

    The boundary check alone catches only two of those three: 7016A3DA IS an
    instruction boundary — it is the link load `XWLDA 3,[ac3+0x7FFA]`, simply
    not the `XWSTA 0,[ac3+0xE]` its own comment quotes.  So the PC is also
    checked to name the instruction the comment cites.  A citation that
    resolves to the wrong instruction is the same defect as one that resolves
    to nothing."""
    bad = []
    insns = _instruction_text()

    def check_witness(label, witness, comment=None):
        if not witness or "@" not in witness:
            bad.append("%s: no named witness (expected NAME@PC)" % label)
            return
        text = witness.rsplit("@", 1)[1]
        try:
            pc = int(text, 16)
        except ValueError:
            bad.append("%s: witness PC %r is not hex" % (label, text))
            return
        if insns is None:
            return
        if pc not in insns:
            bad.append("%s: witness PC %s is not an instruction boundary "
                       "in Disassembled/quest.dis" % (label, text))
            return
        want = _quoted_insn(comment)
        if want is None:
            bad.append("%s: comment does not open with the instruction the "
                       "witness cites" % label)
        elif " ".join(want.split()) != " ".join(insns[pc].split()):
            bad.append("%s: witness PC %s is %r, but the comment cites %r"
                       % (label, text, insns[pc], want))

    for pname, p in PARENT_FRAMES.items():
        for fname, spec in p["locals"].items():
            slot, width, witness = spec[0], spec[1], spec[2]
            if width not in (8, 16, 32):
                bad.append("%s.%s: width %r is not 8/16/32" % (pname, fname, width))
            check_witness("%s.%s" % (pname, fname), witness, spec[3])
        for k, spec in p.get("args", {}).items():
            width, witness = spec[0], spec[1]
            if width not in (8, 16, 32):
                bad.append("%s arg %s: width %r is not 8/16/32" % (pname, k, width))
            check_witness("%s arg %s" % (pname, k), witness, spec[2])
            if not 1 <= k <= p["argc"]:
                bad.append("%s arg %s: outside argc %d" % (pname, k, p["argc"]))
        slots = [s[0] for s in p["locals"].values()]
        if len(slots) != len(set(slots)):
            bad.append("%s: two names for one slot" % pname)
    if bad:
        raise SystemExit("PARENT_FRAMES violates the P39 witness rule:\n  " + "\n  ".join(bad))


def c_type(width):
    return {16: "int16_t", 32: "int32_t"}[width]


def gen_h(digest):
    L = []
    w = L.append
    w("/* declarations.h — GENERATED by compiler/gen_declarations.py; do not edit.")
    w(" * Sources: docs/GAME_REFERENCE.md + docs/Project34/Census.md §3.")
    w(" * table sha256 (of declarations.json): %s" % digest)
    w(" * This is the only game/ file whose C and C++ views differ. */")
    w("#ifndef QUEST_DECLARATIONS_H")
    w("#define QUEST_DECLARATIONS_H")
    w('#include "quest_rt.h"')
    w("")
    w("/* ---- statics (word addresses in the data segment) ---- */")
    for name, (addr, width, cmt) in STATICS.items():
        w("/* %-10s 0x%08X: %s */" % (name, addr, cmt))
    w("")
    w("/* ---- record types: fields at their raw word displacement K from the base pointer ---- */")
    for tname, t in TABLES.items():
        w("/* %s: stride %d words, 1-based origin base+%d; %s */" % (tname, t["stride"], t["minK"] + t["stride"], t["comment"]))
        w("struct %s_rec {" % tname.lower())
        # lay the fields out by K relative to minK
        for fname, spec in sorted(t["fields"].items(), key=lambda kv: kv[1][0]):
            K, width = spec[0], spec[1]
            dims = "".join("[%d]" % d for d in spec[2]) if len(spec) > 2 else ""
            w("    %s %s%s;   /* K=%d%s */" % (c_type(width), fname, dims, K,
                                             ", row strides %s words" % list(spec[3]) if dims else ""))
        w("};")
    for pname, fields in DIRECT.items():
        w("struct %s_hdr {" % pname.lower())
        for fname, (K, width, cmt) in sorted(fields.items(), key=lambda kv: kv[1][0]):
            w("    %s %s;   /* K=%d: %s */" % (c_type(width), fname, K, cmt))
        w("};")
    w("")
    w("/* ---- parent frames: the static link's targets (P39) ----")
    w(" * A nested procedure's UPLINK(P) points at one of these.  Members are at")
    w(" * their WORD displacement off the parent's frame pointer; `__aK` is the")
    w(" * parent's K'th argument (by reference, at wfp-10-2K).")
    w(" *")
    w(" * This view NAMES the slots and type-checks uses; it does NOT reproduce")
    w(" * the frame's layout, and nothing should read offsetof() from it.  It")
    w(" * cannot: the arguments sit at NEGATIVE displacements (wfp-10-2K) and the")
    w(" * locals at positive ones, so no single struct puts both in address")
    w(" * order.  The translator does not read this struct — it reads the same")
    w(" * table from declarations.json, where the slot numbers are exact. */")
    for pname, p in PARENT_FRAMES.items():
        w("struct %s__frame {" % pname)
        for k in range(1, p["argc"] + 1):
            a = p.get("args", {}).get(k)
            ty = "%s *" % c_type(a[0]) if a else "void *"
            note = ("%s: %s" % (a[1], a[2])) if a else "width not witnessed yet"
            w("    %s__a%d;   /* the parent's argument %d, at wfp-%d — %s */"
              % (ty, k, k, 10 + 2 * k, note))
        prev = 0
        for fname, spec in sorted(p["locals"].items(), key=lambda kv: kv[1][0]):
            slot, width, witness, cmt = spec
            if slot > prev:
                w("    int16_t __pad%d[%d];" % (slot, slot - prev))
            w("    %s %s;   /* wp(link, %d) — %s: %s */" % (c_type(width), fname, slot, witness, cmt))
            prev = slot + (width // 16)
        w("};")
    w("")
    w("#ifdef __cplusplus")
    w("/* C++ view: real objects bound to the world image (native runtime, later). */")
    for name, (addr, width, cmt) in STATICS.items():
        if name in DIRECT:
            w("extern based_ptr<struct %s_hdr> %s;   /* 0x%08X */" % (name.lower(), name, addr))
        elif name.endswith("_PTR"):
            w("extern based_ptr<void> %s;   /* 0x%08X */" % (name, addr))
        else:
            w("extern %s %s;   /* 0x%08X */" % (c_type(width), name, addr))
    for tname, t in TABLES.items():
        w("extern ARRAY1(struct %s_rec, %d) %s;   /* via %s, origin +%d */" % (
            tname.lower(), t["bound"], tname, t["base"], t["minK"] + t["stride"]))
    w("#else")
    w("/* C view (pycparser / the translator): plain declarations; the numbers live in declarations.json. */")
    for name, (addr, width, cmt) in STATICS.items():
        if name in DIRECT:
            w("extern struct %s_hdr *%s;   /* 0x%08X */" % (name.lower(), name, addr))
        elif name.endswith("_PTR"):
            w("extern void *%s;   /* 0x%08X */" % (name, addr))
        else:
            w("extern %s %s;   /* 0x%08X */" % (c_type(width), name, addr))
    for tname, t in TABLES.items():
        w("extern struct %s_rec %s[%d];   /* via %s, 1-based, origin +%d */" % (
            tname.lower(), tname, t["bound"], t["base"], t["minK"] + t["stride"]))
    w("#endif")
    w("#endif")
    return "\n".join(x for x in L if x is not None) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "game"))
    args = ap.parse_args()
    check_frames()                      # the P39 witness rule, enforced
    table = dict(frames={p: dict(argc=v["argc"],
                                 args={str(k): dict(width=s[0], witness=s[1], comment=s[2])
                                       for k, s in v.get("args", {}).items()},
                                 locals={n: dict(slot=s[0], width=s[1], witness=s[2], comment=s[3])
                                         for n, s in v["locals"].items()},
                                 # P45: carry the taint markers through to the .json (a001 Q3)
                                 **({"_taint": v["_taint"]} if "_taint" in v else {}))
                         for p, v in PARENT_FRAMES.items()},
                 statics={n: dict(addr=a, width=w, comment=c) for n, (a, w, c) in STATICS.items()},
                 direct={p: {n: dict(K=k, width=w, comment=c) for n, (k, w, c) in f.items()} for p, f in DIRECT.items()},
                 tables={n: dict(base=t["base"], stride=t["stride"], minK=t["minK"], origin=t["minK"] + t["stride"],
                                 bound=t["bound"], comment=t["comment"],
                                 fields={fn: dict(K=sp[0], width=sp[1], **({"dims": list(sp[2]), "strides": list(sp[3])} if len(sp) > 2 else {}))
                                         for fn, sp in t["fields"].items()})
                         for n, t in TABLES.items()})
    js = json.dumps(table, indent=1, sort_keys=True)
    digest = hashlib.sha256(js.encode()).hexdigest()[:16]
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "declarations.json"), "w") as f:
        f.write(js + "\n")
    with open(os.path.join(args.out, "declarations.h"), "w") as f:
        f.write(gen_h(digest))
    print("wrote declarations.h / declarations.json (table %s)" % digest)


if __name__ == "__main__":
    main()
